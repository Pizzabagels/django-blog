from django.contrib import admin
from mysite.blogging import Post

admin.site.register(Post)